import React,{ useState,useEffect } from "react"
import { useParams } from "react-router-dom"
import "./css/ViewMovie.css"

const ViewMovie = () => {
  let ide = useParams()
  let [movies,setMovies] = useState([])
  useEffect(() => {
    const mv = async () => {
      await fetch(`https://moviedb.kanekytg.repl.co/movie/${ide.id}`).then((data) => data.json()).then((movie) => {
        setMovies([movie])
      })
    }
    mv()
  },[])
  return (
    <div className="view">
      <div className="view_db">
        {
          movies.map((mv) => {
            return (
              <div className="view_db_movie">
                <div className="view_db_movie_frame"><iframe src={mv.url} scrolling="no" allowfullscreen="" width="560" height="315" frameborder="0"></iframe></div>
                <div className="view_db_movie_details">
                  <img src={mv.img_url} alt=""/>
                  <h2>{mv.name}</h2>
                  <p>{mv.description}</p>
                </div>
              </div>
            )
          })
        }
      </div>
    </div>
  )
}
export default ViewMovie