import React,{ useContext } from "react"
import { Link } from "react-router-dom"
import { mycontexto } from "../../context/contexto"
import "./css/Barra.css"

const Barra = () => {
  let { setVisible } = useContext(mycontexto)
  return (
    <>
    <div>
      <div className="barra">
        <div className="barra_opciones">
          <div className="barra_opciones_menu"><img onClick={() => setVisible(true)} src="https://cdn.iconscout.com/icon/premium/png-512-thumb/menu-1899371-1606810.png?f=avif&w=512"/></div>
          <div className="barra_opciones_home"><Link to="/"><img src="https://cdn.iconscout.com/icon/premium/png-512-thumb/home-2513392-2104716.png?f=avif&w=512"/></Link></div>
          <div className="barra_opciones_contacto"><img src="https://cdn.iconscout.com/icon/premium/png-512-thumb/contact-us-485563.png?f=avif&w=512"/></div>
        </div>
      </div>
    </div>
    <div>
      <div className="barra2">
        <div className="barra_opciones2">
          <div className="barra_opciones_menu2"><img src="https://cdn.iconscout.com/icon/premium/png-512-thumb/menu-1899371-1606810.png?f=avif&w=512"/></div>
          <div className="barra_opciones_home2"><Link to="/"><img src="https://cdn.iconscout.com/icon/premium/png-512-thumb/home-2513392-2104716.png?f=avif&w=512"/></Link></div>
          <div className="barra_opciones_contacto2"><img src="https://cdn.iconscout.com/icon/premium/png-512-thumb/contact-us-485563.png?f=avif&w=512"/></div>
        </div>
      </div>
    </div>
    </>
  )
}
export default Barra