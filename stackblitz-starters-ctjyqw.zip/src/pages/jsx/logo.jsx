import React from "react"
import "./css/Logo.css"

const Logo = () => {
  return (
    <div className="logo">
      <div className="logo_img"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTV8Q5lNNDxCTs7Z0zLPK_7Xo3JHuVcBvjedQ&usqp=CAU"/></div>
      <div className="logo_name"><h4>CIBER MOVIE</h4></div>
    </div>
  )
}
export default Logo