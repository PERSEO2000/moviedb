import React from "react"
import { Link } from "react-router-dom"
import "./css/Inicio.css"

const Inicio = () => {
  return (
   <div className="inicio">
      <div className="inicio_btn">
        <Link to="/movies"><h1>STAR</h1></Link>
      </div>
    </div>
  )
}
export default Inicio