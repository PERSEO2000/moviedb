import React from "react"
import { Link } from "react-router-dom"
import "./css/Home.css"
import Inicio from "./jsx/inicio"
import Logo from "./jsx/logo"
import Title from "./jsx/title"

const Home = () => {
  return (
    <div className="home">
      <Logo/>
      <Title/>
      <Inicio/>
    </div>
  )
}
export default Home