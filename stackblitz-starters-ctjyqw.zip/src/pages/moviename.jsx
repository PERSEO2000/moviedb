import React,{ useState,useContext,useEffect } from "react"
import { mycontexto } from "../context/contexto.jsx"
import "./css/MovieName.css"

const MovieName = () => {
  let [movies,setMovies] = useState([])
  let { name } = useContext(mycontexto)
  useEffect(() => {
    const mv = async () => {
      await fetch(`https://moviedb.kanekytg.repl.co/moviename/${name}`).then((data) => data.json()).then((movie) => {
        setMovies(movie)
        console.log(movie)
      })
    }
    mv()
  },[name])
  return (
    <div className="view">
    <div className="view_db">
      {movies && movies.length > 0 ? movies.map((mv) => {
          return (
            <div className="view_db_movie">
              <div className="view_db_movie_frame"><iframe src={mv.url} scrolling="no" allowfullscreen="" width="560" height="315" frameborder="0"></iframe></div>
              <div className="view_db_movie_details">
                <img src={mv.img_url} alt=""/>
                <h2>{mv.name}</h2>
                <p>{mv.description}</p>
              </div>
            </div>
          )
        }) 
        : 
        <div className="error">
          <div className="error_img"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTV8Q5lNNDxCTs7Z0zLPK_7Xo3JHuVcBvjedQ&usqp=CAU" alt=""/></div>
          <div className="error_error"><h2>Sin Resultados {name == "" ? "." : "para"} <span>{name}</span> Intenta escribir el nombre correcto</h2></div>
        </div>
      }
    </div>
  </div>
  )
}
export default MovieName