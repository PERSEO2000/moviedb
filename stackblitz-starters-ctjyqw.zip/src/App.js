import React from "react";
import { BrowserRouter,Routes,Route } from "react-router-dom"
import Menu from "./components/menu";
import Contexto from "./context/contexto";
import Home from "./pages/home";
import Barra from "./pages/jsx/barra";
import BarraBottom from "./pages/jsx/barraBottom";
import MovieName from "./pages/moviename";
import Movies from "./pages/movies";
import ViewMovie from "./pages/viewmovie";
import "./style.css";

export default function App() {
  return (
    <BrowserRouter className="app">
      <Contexto>
        <Barra/>
        <Menu/>
          <Routes>
            <Route path="/" element={<Home/>}/>
            <Route path="movies" element={<Movies/>}/>
            <Route path="/view/:id" element={<ViewMovie/>}/>
            <Route path="/movie/" element={<MovieName/>}/>
          </Routes>
        <BarraBottom/>
      </Contexto>
    </BrowserRouter>
  );
}
