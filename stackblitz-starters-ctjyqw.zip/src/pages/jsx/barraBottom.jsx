import React,{ useRef,useContext } from "react"
import { mycontexto } from "../../context/contexto.jsx"
import { Link } from "react-router-dom"
import "./css/BarraBottom.css"

const BarraBottom = () => {
  let { setName } = useContext(mycontexto)
  let name = useRef()
  return (
    <>
    <div className="barrabottom">
      <div className="barrabottom_opcion">
      <div className="barrabottom_opcion_send"><input ref={name} type="text" placeholder="serch movie"/><Link to="/movie"><img onClick={() => setName(name.current.value)} src="https://cdn.iconscout.com/icon/premium/png-512-thumb/send-2651476-2198417.png?f=avif&w=512"/></Link></div>
      </div>
    </div>
    <div className="barrabottom2">
      <div className="barrabottom_opcion2">
      <div className="barrabottom_opcion_send2"><input type="text" placeholder="serch movie"/><img src="https://cdn.iconscout.com/icon/premium/png-512-thumb/send-2651476-2198417.png?f=avif&w=512"/></div>
      </div>
    </div>
    </>
  )
}
export default BarraBottom