import React,{ useState,useEffect } from "react"
import { Link } from "react-router-dom"
import "./css/Movies.css"

const Movies = () => {
  let [movies,setMovies] = useState([])
  useEffect(() => {
    const mv = async () => {
      await fetch("https://moviedb.kanekytg.repl.co/movies").then((data) => data.json()).then((movie) => {
        setMovies(movie)
      })
    }
    mv()
  },[])
  return (
    <div className="movies">
      <div className="movies_db">
        {
          movies.map((mvs) => {
            return (
              <div className="movies_db_movie">
                <div className="movies_db_movie_img"><Link to={`/view/${mvs.id}`}><img src={mvs.img_url}/></Link></div>
                <div className="movies_db_movie_p"><p>{mvs.name}</p></div>
              </div>
            )
          })
        }
      </div>
    </div>
  )
}
export default Movies