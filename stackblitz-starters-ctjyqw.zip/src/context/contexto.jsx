import React,{ createContext,useState } from "react"

export let mycontexto = createContext()

const Contexto = ({children}) => {
  let [ name,setName ] = useState("")
  let [visible,setVisible] = useState(true)
  return (
    <mycontexto.Provider value={{name,setName,visible,setVisible}}>
      {children}
    </mycontexto.Provider>
  )
}
export default Contexto