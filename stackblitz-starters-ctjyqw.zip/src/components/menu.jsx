import React,{ useRef,useContext,useState,useEffect } from "react"
import { Link } from "react-router-dom"
import { mycontexto } from "../context/contexto.jsx"
import "./css/Menu.css"

const Menu = () => {
  let p = useRef()
  let { visible,setVisible,setName } = useContext(mycontexto)
  let [names,setNames] = useState([])
  useEffect(() => {
    const mv = async () => {
      await fetch("https://moviedb.kanekytg.repl.co/movienames").then((data) => data.json()).then((namesdata) => {
        setNames(namesdata)
      })
    }
    mv()
  },[])
  return (
    <div className="menu" style={visible ? {display: "flex"} : {display: "none"}}>
      <div className="menu_opcion">
        {
          names.map((nm) => {
            return (
              <div className="menu_opcion_name">
                <div><Link to="/movie"><p onClick={(e) => setName(e.target.innerHTML)}>{nm.name}</p></Link></div>
              </div>
            )
          })
        }
      </div>
      <div onClick={() => setVisible(false)} className="close">{"<"}</div>
    </div>
  )
}
export default Menu