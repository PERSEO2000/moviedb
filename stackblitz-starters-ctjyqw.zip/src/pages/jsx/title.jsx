import React from "react"
import { Link } from "react-router-dom"
import "./css/Title.css"

const Title = () => {
  return (
    <div className="title">
      <div className="title_title">
        <h1>CIBER MOVIE</h1>
      </div>
    </div>
  )
}
export default Title